# AWFLMETA API Server v2.0 — Documentation

**Enhanced Node.js API for AEDTP WORLD's AWFLMETA Platform**

---

## Overview

The AWFLMETA API Server is a Node.js backend that manages wiki content creation, image uploads, and metadata indexing for the AEDTP WORLD platform. It integrates with GitHub to store and retrieve content in a distributed, version-controlled manner.

### Key Features

✅ **Multi-Category Support** — 12+ content categories (AI, Apps, Artists, Bible, Biography, Business, Developer, Dictionary, Education, Legacy, Music, News, AWFL)

✅ **Smart Caching** — In-memory index caching with automatic invalidation

✅ **Rate Limiting** — Per-IP request throttling (100 req/min default)

✅ **Comprehensive Validation** — Input sanitization, slug validation, file type checking

✅ **Error Handling** — Detailed error responses with actionable feedback

✅ **Health Diagnostics** — Real-time server health and metrics

✅ **Graceful Shutdown** — Proper signal handling (SIGTERM, SIGINT)

---

## Deployment on Render

### Prerequisites

- Node.js 18+ runtime
- GitHub Personal Access Token (PAT) with `repo` scope
- Render account (www.render.com)

### Step-by-Step Deployment

#### 1. Create GitHub Personal Access Token

1. Go to https://github.com/settings/tokens
2. Click "Generate new token" → "Generate new token (classic)"
3. Name: `awflmeta-api-token`
4. Scopes: Check `repo` (full control of private repositories)
5. Expiration: 90 days or custom
6. Click "Generate token" and **copy it immediately** (you won't see it again)

#### 2. Create a Render Service

1. Go to https://dashboard.render.com
2. Click "New +" → "Web Service"
3. Connect your GitHub repository: `aedtpworldawfl/awflmeta`
4. Configure:
   - **Name**: `awflmeta-api`
   - **Environment**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `node api/server.js`
   - **Instance Type**: Free (or Starter Pro for production)

#### 3. Set Environment Variables

In Render dashboard, go to "Environment" and add:

```
GH_TOKEN=ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxx
GH_OWNER=aedtpworldawfl
GH_REPO=awflmeta
GH_BRANCH=main
NODE_ENV=production
```

#### 4. Deploy

Click "Create Web Service" — Render will automatically deploy and provide a public URL:

```
https://awflmeta-api.onrender.com
```

### Environment Variables Reference

| Variable | Required | Default | Example |
|----------|----------|---------|---------|
| `GH_TOKEN` | ✓ Yes | - | `ghp_xxxx...` |
| `GH_OWNER` | ✓ Yes | `aedtpworldawfl` | - |
| `GH_REPO` | ✓ Yes | `awflmeta` | - |
| `GH_BRANCH` | - | `main` | `main` or `master` |
| `PORT` | - | `10000` | Render sets this automatically |
| `NODE_ENV` | - | `production` | `production` or `development` |

---

## API Endpoints

### Health & Diagnostics

#### GET `/api/health`

Server health check with full diagnostics.

**Response** (200 OK):
```json
{
  "ok": true,
  "service": "awflmeta-api",
  "version": "2.0.0",
  "timestamp": "2026-05-19T10:30:00.000Z",
  "uptime": 3600,
  "environment": "production",
  "config": {
    "owner": "aedtpworldawfl",
    "repo": "awflmeta",
    "branch": "main",
    "port": 10000,
    "tokenConfigured": true
  },
  "categories": ["ai", "apps", "artists", "bible", "biography", "business", "developer", "dictionary", "education", "legacy", "music", "news", "awfl"],
  "cacheSize": 3,
  "rateLimitEntries": 2
}
```

#### GET `/api/stats`

Detailed server metrics and statistics.

**Response** (200 OK):
```json
{
  "server": {
    "uptime": 3600,
    "memory": {
      "rss": 52428800,
      "heapTotal": 31457280,
      "heapUsed": 15728640,
      "external": 1048576
    },
    "env": "production"
  },
  "cache": {
    "entries": 5,
    "keys": ["index_music", "index_artists", "index_biography", "index_business", "index_news"]
  },
  "rateLimit": {
    "activeEntries": 3
  },
  "api": {
    "version": "2.0.0",
    "categories": 13,
    "supportedCats": ["ai", "apps", "artists", ...]
  }
}
```

---

### Wiki Content Management

#### POST `/api/awflmeta/publish`

Create or update a wiki page in any category.

**Request Headers:**
```
Content-Type: application/json
Origin: https://aedtpworldawfl.github.io
```

**Request Body:**
```json
{
  "slug": "Buddy_DML",
  "title": "Buddy DML - The Trenchkid TM",
  "category": "music",
  "wikiHTML": "<html>...</html>",
  "author": "Emmanuel Deliver Amable",
  "description": "Musical artist from Ghana",
  "tags": ["music", "ghana", "artist"]
}
```

**Parameters:**
- `slug` (required) — Page identifier; alphanumeric, hyphens, dots, parentheses allowed; max 200 chars
- `title` (required) — Display title; 1-500 characters
- `category` (required) — One of: `ai`, `apps`, `artists`, `bible`, `biography`, `business`, `developer`, `dictionary`, `education`, `legacy`, `music`, `news`, `awfl`
- `wikiHTML` (required) — Full HTML content of the page
- `author` (optional) — Author name; defaults to "anonymous"
- `description` (optional) — Short description (max 500 chars)
- `tags` (optional) — Array of tag strings (max 20 tags)
- `infoboxData` (optional) — Structured metadata object

**Response** (201 Created):
```json
{
  "success": true,
  "message": "Page published successfully",
  "data": {
    "slug": "Buddy_DML",
    "category": "music",
    "url": "https://aedtpworldawfl.github.io/awflmeta/music/Buddy_DML.html",
    "published": "2026-05-19T10:30:00.000Z"
  }
}
```

**Error Responses:**
```json
// 400 Bad Request — Invalid slug
{
  "error": "Invalid slug format",
  "example": "Buddy_DML or Artist_Name_2024"
}

// 400 Bad Request — Invalid category
{
  "error": "Invalid category",
  "supported": ["ai", "apps", "artists", ...]
}

// 500 Internal Server Error
{
  "error": "Server not configured",
  "issue": "GH_TOKEN is missing"
}

// 429 Too Many Requests
{
  "error": "Rate limit exceeded. Max 100 requests per minute."
}
```

**Example cURL:**
```bash
curl -X POST https://awflmeta-api.onrender.com/api/awflmeta/publish \
  -H "Content-Type: application/json" \
  -d '{
    "slug": "Buddy_DML",
    "title": "Buddy DML",
    "category": "artists",
    "wikiHTML": "<h1>Buddy DML</h1><p>Content here...</p>",
    "author": "Emmanuel Deliver Amable"
  }'
```

**Example JavaScript/Fetch:**
```javascript
const response = await fetch('https://awflmeta-api.onrender.com/api/awflmeta/publish', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    slug: 'Buddy_DML_Fun_Song_2026',
    title: 'Buddy DML - Fun (Song)',
    category: 'music',
    wikiHTML: '<h1>New Song</h1><p>...</p>',
    author: 'Your Name',
    description: 'A new track by Buddy DML',
    tags: ['music', '2026', 'song']
  })
});

const data = await response.json();
console.log(data.data.url); // https://...
```

---

#### GET `/api/awflmeta/pages?category=CATEGORY`

List all pages in a category, or show available categories.

**Query Parameters:**
- `category` (optional) — Category name (e.g., `music`, `artists`)

**Response** (200 OK) — If category specified:
```json
{
  "category": "music",
  "count": 42,
  "pages": [
    {
      "slug": "Buddy_DML",
      "title": "Buddy DML",
      "category": "music",
      "updated": 1716113400000,
      "author": "Emmanuel Deliver Amable",
      "description": "Musical artist from Ghana",
      "tags": ["music", "ghana"]
    }
  ],
  "cached": 1716113400000
}
```

**Response** (200 OK) — If no category specified:
```json
{
  "categories": ["ai", "apps", "artists", "bible", "biography", "business", "developer", "dictionary", "education", "legacy", "music", "news", "awfl"],
  "description": "Available AWFLMETA categories"
}
```

**Example cURL:**
```bash
# List music category pages
curl https://awflmeta-api.onrender.com/api/awflmeta/pages?category=music

# List available categories
curl https://awflmeta-api.onrender.com/api/awflmeta/pages
```

---

#### GET `/api/awflmeta/page/:category/:slug`

Get a single page's metadata.

**Path Parameters:**
- `category` — Category name (e.g., `music`)
- `slug` — Page identifier (e.g., `Buddy_DML`)

**Response** (200 OK):
```json
{
  "success": true,
  "page": {
    "slug": "Buddy_DML",
    "title": "Buddy DML",
    "category": "music",
    "updated": 1716113400000,
    "author": "Emmanuel Deliver Amable",
    "description": "Musical artist from Ghana",
    "tags": ["music", "ghana"]
  },
  "url": "https://aedtpworldawfl.github.io/awflmeta/music/Buddy_DML.html"
}
```

**Example cURL:**
```bash
curl https://awflmeta-api.onrender.com/api/awflmeta/page/music/Buddy_DML
```

---

### Image Upload

#### POST `/api/upload/image`

Upload an image (JPEG or PNG) to the `images/` directory.

**Request Format:**
- Content-Type: `multipart/form-data`
- Form field: `image` (file input)
- Max size: 5MB

**Response** (201 Created):
```json
{
  "success": true,
  "message": "Image uploaded successfully",
  "data": {
    "fileName": "myimage_1716113400000_a1b2c3d4.jpg",
    "url": "https://aedtpworldawfl.github.io/awflmeta/images/myimage_1716113400000_a1b2c3d4.jpg",
    "size": 245632,
    "type": "image/jpeg",
    "uploaded": "2026-05-19T10:30:00.000Z"
  }
}
```

**Example cURL:**
```bash
curl -X POST https://awflmeta-api.onrender.com/api/upload/image \
  -F "image=@/path/to/image.jpg"
```

**Example JavaScript/FormData:**
```javascript
const formData = new FormData();
formData.append('image', fileInput.files[0]);

const response = await fetch('https://awflmeta-api.onrender.com/api/upload/image', {
  method: 'POST',
  body: formData
});

const data = await response.json();
console.log(data.data.url); // Direct image URL
```

**Error Responses:**
```json
// 413 Payload Too Large
{
  "error": "File too large (max 5MB)"
}

// 415 Unsupported Media Type
{
  "error": "Only JPEG and PNG images are supported",
  "received": "image/webp"
}

// 400 Bad Request
{
  "error": "Missing \"image\" field in multipart form"
}

// 429 Too Many Requests
{
  "error": "Rate limit exceeded"
}
```

---

### Cache Management

#### POST `/api/cache/clear?category=CATEGORY`

Clear index caches (useful after bulk updates).

**Query Parameters:**
- `category` (optional) — Specific category to clear; omit to clear all

**Response** (200 OK) — Clear specific category:
```json
{
  "success": true,
  "message": "Cache cleared for category: music",
  "cleared": ["music"]
}
```

**Response** (200 OK) — Clear all:
```json
{
  "success": true,
  "message": "All cache cleared",
  "clearedAll": true
}
```

**Example cURL:**
```bash
# Clear music category cache
curl -X POST https://awflmeta-api.onrender.com/api/cache/clear?category=music

# Clear all caches
curl -X POST https://awflmeta-api.onrender.com/api/cache/clear
```

---

## CORS Configuration

The API accepts requests from these origins:

- `https://aedtpworldawfl.github.io` (production)
- `http://localhost:3000` (local development)
- `http://localhost:5500` (Live Server)
- `http://127.0.0.1:5500` (Live Server)

To add more origins, modify the `ALLOWED_ORIGINS` array in `server.js`.

---

## Rate Limiting

**Default Limits:**
- **100 requests per minute** per IP address
- Tracked via `X-Forwarded-For` or direct socket IP

**When exceeded:**
- HTTP 429 (Too Many Requests)
- Error message: "Rate limit exceeded. Max 100 requests per minute."

Adjust in `server.js`:
```javascript
const RATE_LIMIT = {
  maxRequests: 100,  // Change this
  windowMs: 60000,   // or this (milliseconds)
};
```

---

## Supported Categories

The API supports content creation in these 13 categories:

1. **AI** — Artificial Intelligence
2. **Apps** — Applications
3. **Artists** — Musicians and artists
4. **Bible** — Religious content
5. **Biography** — Biographical information
6. **Business** — Business information
7. **Developer** — Developer resources
8. **Dictionary** — Definitions and terms
9. **Education** — Educational content
10. **Legacy** — Historical/archived content
11. **Music** — Music and discography
12. **News** — News and updates
13. **AWFL** — AEDTP WORLD Free License content

---

## Error Handling

All error responses follow this format:

```json
{
  "error": "Short error message",
  "timestamp": "2026-05-19T10:30:00.000Z",
  "details": {
    "additional": "context"
  }
}
```

**Common Status Codes:**

| Code | Meaning |
|------|---------|
| 200 | Success (GET requests) |
| 201 | Created (POST requests successful) |
| 204 | No Content (CORS preflight) |
| 400 | Bad Request (validation error) |
| 404 | Not Found (endpoint/resource missing) |
| 413 | Payload Too Large (file > 5MB) |
| 415 | Unsupported Media Type (wrong file format) |
| 429 | Too Many Requests (rate limited) |
| 500 | Internal Server Error |
| 502 | Bad Gateway (GitHub API unreachable) |

---

## Development & Local Testing

### Run Locally

```bash
# Clone repo
git clone https://github.com/aedtpworldawfl/awflmeta.git
cd awflmeta

# Install dependencies
npm install

# Create .env file
cat > .env << EOF
GH_TOKEN=ghp_your_token_here
GH_OWNER=aedtpworldawfl
GH_REPO=awflmeta
GH_BRANCH=main
PORT=10000
NODE_ENV=development
EOF

# Start server
node api/server.js
```

### Test with cURL

```bash
# Health check
curl http://localhost:10000/api/health

# List categories
curl http://localhost:10000/api/awflmeta/pages

# Publish (requires valid GH_TOKEN)
curl -X POST http://localhost:10000/api/awflmeta/publish \
  -H "Content-Type: application/json" \
  -d '{
    "slug": "Test_Page",
    "title": "Test Page",
    "category": "awfl",
    "wikiHTML": "<h1>Test</h1>"
  }'
```

---

## Troubleshooting

### "GH_TOKEN is missing"

**Problem:** Server responds with error "Server not configured (GH_TOKEN missing)"

**Solution:**
1. Verify `GH_TOKEN` is set in Render environment variables
2. Ensure token has `repo` scope
3. Token may have expired — generate a new one and update in Render dashboard

### "GitHub write failed: Bad credentials"

**Problem:** Token is invalid or expired

**Solution:**
1. Generate a new token at https://github.com/settings/tokens
2. Update `GH_TOKEN` in Render dashboard
3. Redeploy (Render will restart the service)

### "Rate limit exceeded"

**Problem:** Too many requests from your IP

**Solution:**
- Wait 60 seconds before retrying
- Batch requests if possible
- Contact support if you need higher limits

### "Invalid category"

**Problem:** Used unsupported category in request

**Solution:**
- Call `GET /api/awflmeta/pages` to see supported categories
- Use exact lowercase category names (e.g., `music`, not `Music`)

---

## Performance Tips

1. **Cache aggressively** — Index data is cached for 5 minutes automatically
2. **Batch uploads** — Upload multiple images in single requests if possible
3. **Reuse connections** — HTTP keep-alive enabled by default
4. **Monitor uptime** — Check `/api/health` regularly

---

## Security

- ✅ Input validation on all endpoints
- ✅ Slug and filename sanitization
- ✅ CORS protection
- ✅ Rate limiting per IP
- ✅ File type validation (images only: JPEG/PNG)
- ✅ Size limits (5MB images, 10MB wiki content)

⚠️ **Keep GH_TOKEN secret!** Never commit it to version control or expose it in client-side code.

---

## Support & Contact

- **Email:** aedtpworld@gmail.com
- **Creator:** Emmanuel Deliver Amable
- **Organization:** AEDTP WORLD
- **Location:** Volta Region, Ghana 🇬🇭
- **Repository:** https://github.com/aedtpworldawfl/awflmeta

---

## License

**AEDTP WORLD FREE LICENSE (AWFL) v1.0.0**

© 2024-2026 AEDTP WORLD. All Rights Reserved.

See `/api/awflmeta/license/` for full license terms.
